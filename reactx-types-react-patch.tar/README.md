# reactx-types-react-patch
Patch of @types/react
